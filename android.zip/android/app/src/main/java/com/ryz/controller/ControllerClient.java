// ControllerClient.java
// WebSocket client — konek ke AgentService di HP kedua

package com.ryz.controller;

import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.nio.ByteBuffer;

public class ControllerClient {

    public interface FrameListener    { void onFrame(byte[] data); }
    public interface MessageListener  { void onMessage(String msg); }
    public interface StatusListener   { void onEvent(); }

    private WebSocketClient wsClient;
    private final String url;
    private final StatusListener onConnected;
    private final StatusListener onDisconnected;
    private final FrameListener  onFrame;
    private final MessageListener onMessage;

    public ControllerClient(String url,
                            StatusListener onConnected,
                            StatusListener onDisconnected,
                            FrameListener onFrame,
                            MessageListener onMessage) {
        this.url           = url;
        this.onConnected   = onConnected;
        this.onDisconnected = onDisconnected;
        this.onFrame       = onFrame;
        this.onMessage     = onMessage;
    }

    public void connect() {
        try {
            wsClient = new WebSocketClient(new URI(url)) {
                @Override
                public void onOpen(ServerHandshake handshake) {
                    onConnected.onEvent();
                }

                @Override
                public void onMessage(String message) {
                    onMessage.onMessage(message);
                }

                @Override
                public void onMessage(ByteBuffer bytes) {
                    byte[] data = new byte[bytes.remaining()];
                    bytes.get(data);
                    onFrame.onFrame(data);
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    onDisconnected.onEvent();
                }

                @Override
                public void onError(Exception ex) {
                    onDisconnected.onEvent();
                }
            };
            wsClient.connect();
        } catch (Exception e) {
            onDisconnected.onEvent();
        }
    }

    public void sendCommand(String cmd) {
        if (wsClient != null && wsClient.isOpen()) {
            wsClient.send(cmd);
        }
    }

    public boolean isConnected() {
        return wsClient != null && wsClient.isOpen();
    }

    public void disconnect() {
        if (wsClient != null) wsClient.close();
    }
}
