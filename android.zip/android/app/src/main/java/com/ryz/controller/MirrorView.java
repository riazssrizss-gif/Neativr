// MirrorView.java
// View custom untuk menampilkan stream layar HP kedua
// + scale koordinat sentuhan sesuai resolusi agent

package com.ryz.controller;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

public class MirrorView extends View {

    public interface SwipeListener {
        void onSwipe(float x1, float y1, float x2, float y2);
    }

    private Bitmap currentFrame;
    private final Paint paint = new Paint(Paint.FILTER_BITMAP_FLAG);
    private final Paint placeholderPaint = new Paint();

    private int agentWidth  = 1080;
    private int agentHeight = 1920;

    private float swipeStartX, swipeStartY;
    private SwipeListener swipeListener;

    public MirrorView(Context context, AttributeSet attrs) {
        super(context, attrs);
        placeholderPaint.setColor(Color.parseColor("#1A1A1A"));
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (currentFrame != null) {
            canvas.drawBitmap(currentFrame, null,
                new android.graphics.RectF(0, 0, getWidth(), getHeight()), paint);
        } else {
            canvas.drawRect(0, 0, getWidth(), getHeight(), placeholderPaint);
            Paint textPaint = new Paint();
            textPaint.setColor(Color.GRAY);
            textPaint.setTextSize(40f);
            textPaint.setTextAlign(Paint.Align.CENTER);
            canvas.drawText("Menunggu koneksi...", getWidth() / 2f, getHeight() / 2f, textPaint);
        }
    }

    public void updateFrame(byte[] jpegBytes) {
        Bitmap bmp = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.length);
        if (bmp != null) {
            if (currentFrame != null) currentFrame.recycle();
            currentFrame = bmp;
            postInvalidate();
        }
    }

    public void setAgentResolution(int w, int h) {
        agentWidth  = w;
        agentHeight = h;
    }

    public float[] scaleToAgent(float viewX, float viewY) {
        float scaleX = (float) agentWidth  / getWidth();
        float scaleY = (float) agentHeight / getHeight();
        return new float[]{ viewX * scaleX, viewY * scaleY };
    }

    public void trackMove(float x, float y) {
        // reserved — swipe dikirim saat ACTION_UP via triggerSwipe
    }

    public void setSwipeStart(float x, float y) {
        swipeStartX = x;
        swipeStartY = y;
    }

    public void triggerSwipe(float endX, float endY) {
        if (swipeListener != null) {
            swipeListener.onSwipe(swipeStartX, swipeStartY, endX, endY);
        }
    }

    public void setSwipeListener(SwipeListener listener) {
        this.swipeListener = listener;
    }
}
