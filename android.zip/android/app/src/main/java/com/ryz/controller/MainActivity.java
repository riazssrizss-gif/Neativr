// Controller — HP Utama
// File: MainActivity.java
// Target: Android 8.0+ (API 26+)

package com.ryz.controller;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {

    private ControllerClient client;
    private MirrorView mirrorView;
    private TextView tvStatus;
    private Button btnRestart;
    private Button btnConnect;
    private EditText etIp;

    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvStatus   = findViewById(R.id.tvStatus);
        btnRestart = findViewById(R.id.btnRestart);
        btnConnect = findViewById(R.id.btnConnect);
        etIp       = findViewById(R.id.etIp);
        mirrorView = findViewById(R.id.mirrorView);

        btnConnect.setOnClickListener(v -> {
            String ip = etIp.getText().toString().trim();
            if (ip.isEmpty()) {
                Toast.makeText(this, "Masukkan IP HP kedua", Toast.LENGTH_SHORT).show();
                return;
            }
            connectToAgent(ip);
        });

        btnRestart.setEnabled(false);
        btnRestart.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                .setTitle("Restart HP Kedua?")
                .setMessage("HP kedua akan direstart.")
                .setPositiveButton("Ya", (d, w) -> {
                    if (client != null) client.sendCommand("REBOOT");
                    setStatus("Perintah reboot dikirim...", false);
                })
                .setNegativeButton("Batal", null)
                .show();
        });

        // Touch di mirrorView → kirim ke agent
        mirrorView.setOnTouchListener((v, event) -> {
            if (client == null || !client.isConnected()) return false;

            int action = event.getAction();
            float touchX = event.getX();
            float touchY = event.getY();

            float[] scaled = mirrorView.scaleToAgent(touchX, touchY);

            if (action == MotionEvent.ACTION_DOWN) {
                mirrorView.setSwipeStart(touchX, touchY);
                client.sendCommand("TAP:" + scaled[0] + ":" + scaled[1]);
            } else if (action == MotionEvent.ACTION_UP) {
                mirrorView.triggerSwipe(touchX, touchY);
            } else if (action == MotionEvent.ACTION_MOVE) {
                mirrorView.trackMove(touchX, touchY);
            }
            return true;
        });

        // Swipe callback dari MirrorView
        mirrorView.setSwipeListener((x1, y1, x2, y2) -> {
            if (client == null) return;
            float[] s1 = mirrorView.scaleToAgent(x1, y1);
            float[] s2 = mirrorView.scaleToAgent(x2, y2);
            client.sendCommand("SWIPE:" + s1[0] + ":" + s1[1] + ":" + s2[0] + ":" + s2[1] + ":300");
        });
    }

    private void connectToAgent(String ip) {
        setStatus("Menghubungkan ke " + ip + "...", false);
        btnConnect.setEnabled(false);

        client = new ControllerClient("ws://" + ip + ":9876",
            // onConnected
            () -> mainHandler.post(() -> {
                setStatus("✓ Terhubung ke " + ip, true);
                btnRestart.setEnabled(true);
                btnConnect.setEnabled(true);
                client.sendCommand("INFO");
            }),
            // onDisconnected
            () -> mainHandler.post(() -> {
                setStatus("✗ Koneksi terputus", false);
                btnRestart.setEnabled(false);
                btnConnect.setEnabled(true);
            }),
            // onFrame
            frameBytes -> mainHandler.post(() -> mirrorView.updateFrame(frameBytes)),
            // onMessage
            msg -> mainHandler.post(() -> {
                if (msg.startsWith("INFO:")) {
                    String[] parts = msg.split(":");
                    int agentW = Integer.parseInt(parts[1]);
                    int agentH = Integer.parseInt(parts[2]);
                    mirrorView.setAgentResolution(agentW, agentH);
                } else if (msg.equals("REBOOT_FAILED:needs_root")) {
                    Toast.makeText(this, "Reboot gagal — HP kedua butuh root", Toast.LENGTH_LONG).show();
                }
            })
        );
        client.connect();
    }

    private void setStatus(String msg, boolean connected) {
        tvStatus.setText(msg);
        tvStatus.setTextColor(connected ?
            getColor(android.R.color.holo_green_light) :
            getColor(android.R.color.holo_red_light));
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (client != null) client.disconnect();
    }
}
