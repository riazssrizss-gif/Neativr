// ============================================================
//  config.js — isi semua field ini sebelum jalankan build.js
// ============================================================

module.exports = {
  // --- GitHub ---
  github: {
    token:    "ghp_XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX",  // Personal Access Token (repo + workflow scope)
    owner:    "username_github_lo",   // username GitHub lo
    repo:     "remote-controller",   // nama repo yang akan dibuat / sudah ada
    branch:   "main",
  },

  // --- APK ---
  apk: {
    appId:       "com.ryz.controller",
    appName:     "Remote Controller",
    versionCode: 1,
    versionName: "1.0",
    minSdk:      26,
    targetSdk:   34,
  },

  // --- Keystore (opsional — kosongkan semua kalau mau debug signing) ---
  keystore: {
    use: false,              // true = pakai keystore custom, false = debug signing
    storePassword: "ryz12345",
    keyAlias:      "ryz",
    keyPassword:   "ryz12345",
  },
};
