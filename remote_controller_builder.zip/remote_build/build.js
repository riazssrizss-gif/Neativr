#!/usr/bin/env node
// build.js
// Jalankan: node build.js
// Butuh: node 18+, npm install dulu

const { Octokit } = require("@octokit/rest");
const fs   = require("fs");
const path = require("path");
const cfg  = require("./config");

const octokit = new Octokit({ auth: cfg.github.token });
const { owner, repo, branch } = cfg.github;

// ── util ──────────────────────────────────────────────────
function b64(str)      { return Buffer.from(str).toString("base64"); }
function b64file(fp)   { return fs.readFileSync(fp).toString("base64"); }
function sleep(ms)     { return new Promise(r => setTimeout(r, ms)); }

function log(msg) {
  const t = new Date().toLocaleTimeString("id-ID");
  console.log(`[${t}] ${msg}`);
}

// ── 1. Buat repo kalau belum ada ─────────────────────────
async function ensureRepo() {
  try {
    await octokit.repos.get({ owner, repo });
    log(`Repo ${owner}/${repo} sudah ada.`);
  } catch (e) {
    if (e.status === 404) {
      log("Buat repo baru...");
      await octokit.repos.createForAuthenticatedUser({
        name: repo,
        private: true,
        auto_init: true,
      });
      await sleep(2000);
      log("Repo dibuat.");
    } else throw e;
  }
}

// ── 2. Push satu file ke repo ────────────────────────────
async function pushFile(repoPath, localPath, msg) {
  const content = b64file(path.join(__dirname, localPath));
  let sha;
  try {
    const { data } = await octokit.repos.getContent({ owner, repo, path: repoPath });
    sha = data.sha;
  } catch (_) {}

  await octokit.repos.createOrUpdateFileContents({
    owner, repo,
    path:    repoPath,
    message: msg || `update ${repoPath}`,
    content,
    sha,
    branch,
  });
}

async function pushText(repoPath, text, msg) {
  const content = b64(text);
  let sha;
  try {
    const { data } = await octokit.repos.getContent({ owner, repo, path: repoPath });
    sha = data.sha;
  } catch (_) {}

  await octokit.repos.createOrUpdateFileContents({
    owner, repo,
    path:    repoPath,
    message: msg || `update ${repoPath}`,
    content,
    sha,
    branch,
  });
}

// ── 3. Generate build.gradle dari config ────────────────
function generateBuildGradle() {
  const { appId, versionCode, versionName, minSdk, targetSdk } = cfg.apk;
  const ks = cfg.keystore;

  const signingBlock = ks.use ? `
    signingConfigs {
        release {
            storeFile file("\${rootDir}/keystore/ryz.keystore")
            storePassword '${ks.storePassword}'
            keyAlias '${ks.keyAlias}'
            keyPassword '${ks.keyPassword}'
        }
    }` : "";

  const signingRef = ks.use
    ? "signingConfig signingConfigs.release"
    : "signingConfig signingConfigs.debug";

  return `plugins {
    id 'com.android.application'
}

android {
    namespace '${appId}'
    compileSdk ${targetSdk}
    defaultConfig {
        applicationId "${appId}"
        minSdk ${minSdk}
        targetSdk ${targetSdk}
        versionCode ${versionCode}
        versionName "${versionName}"
    }
    ${signingBlock}
    buildTypes {
        release {
            minifyEnabled false
            ${signingRef}
        }
    }
    compileOptions {
        sourceCompatibility JavaVersion.VERSION_1_8
        targetCompatibility JavaVersion.VERSION_1_8
    }
}

dependencies {
    implementation 'androidx.appcompat:appcompat:1.6.1'
    implementation 'org.java-websocket:Java-WebSocket:1.5.4'
}
`;
}

// ── 4. Push semua file Android project ──────────────────
async function pushAndroidProject() {
  log("Push source code...");

  const files = [
    ["android/settings.gradle",                            "android/settings.gradle"],
    ["android/build.gradle",                               "android/build.gradle"],
    ["android/gradle.properties",                          "android/gradle.properties"],
    ["android/gradlew",                                    "android/gradlew"],
    ["android/gradle/wrapper/gradle-wrapper.jar",          "android/gradle/wrapper/gradle-wrapper.jar"],
    ["android/gradle/wrapper/gradle-wrapper.properties",   "android/gradle/wrapper/gradle-wrapper.properties"],
    ["android/app/src/main/AndroidManifest.xml",           "android/app/src/main/AndroidManifest.xml"],
    ["android/app/src/main/res/layout/activity_main.xml",  "android/app/src/main/res/layout/activity_main.xml"],
    ["android/app/src/main/res/values/strings.xml",        "android/app/src/main/res/values/strings.xml"],
    ["android/app/src/main/java/com/ryz/controller/MainActivity.java",   "android/app/src/main/java/com/ryz/controller/MainActivity.java"],
    ["android/app/src/main/java/com/ryz/controller/ControllerClient.java","android/app/src/main/java/com/ryz/controller/ControllerClient.java"],
    ["android/app/src/main/java/com/ryz/controller/MirrorView.java",     "android/app/src/main/java/com/ryz/controller/MirrorView.java"],
    // icons
    ["android/app/src/main/res/mipmap-hdpi/ic_launcher.png",        "android/app/src/main/res/mipmap-hdpi/ic_launcher.png"],
    ["android/app/src/main/res/mipmap-hdpi/ic_launcher_round.png",  "android/app/src/main/res/mipmap-hdpi/ic_launcher_round.png"],
    ["android/app/src/main/res/mipmap-mdpi/ic_launcher.png",        "android/app/src/main/res/mipmap-mdpi/ic_launcher.png"],
    ["android/app/src/main/res/mipmap-mdpi/ic_launcher_round.png",  "android/app/src/main/res/mipmap-mdpi/ic_launcher_round.png"],
    ["android/app/src/main/res/mipmap-xhdpi/ic_launcher.png",       "android/app/src/main/res/mipmap-xhdpi/ic_launcher.png"],
    ["android/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png", "android/app/src/main/res/mipmap-xhdpi/ic_launcher_round.png"],
    ["android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png",       "android/app/src/main/res/mipmap-xxhdpi/ic_launcher.png"],
    ["android/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png", "android/app/src/main/res/mipmap-xxhdpi/ic_launcher_round.png"],
    ["android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png",       "android/app/src/main/res/mipmap-xxxhdpi/ic_launcher.png"],
    ["android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png", "android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_round.png"],
  ];

  for (const [repoPath, localRel] of files) {
    await pushFile(repoPath, localRel, `add ${repoPath}`);
  }

  // build.gradle generate dari config
  await pushText("android/app/build.gradle", generateBuildGradle(), "add app/build.gradle");
  log("Source code pushed.");
}

// ── 5. Push GitHub Actions workflow ─────────────────────
async function pushWorkflow() {
  log("Push workflow...");
  const workflow = `name: Build APK

on:
  push:
    branches: [ main ]
  workflow_dispatch:

jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4

      - uses: actions/setup-java@v4
        with:
          java-version: '17'
          distribution: 'temurin'

      - name: Make gradlew executable
        run: chmod +x android/gradlew

      - name: Build Release APK
        working-directory: android
        run: ./gradlew assembleRelease

      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: remote-controller
          path: android/app/build/outputs/apk/release/*.apk
          retention-days: 7
`;
  await pushText(".github/workflows/build.yml", workflow, "add build workflow");
  log("Workflow pushed.");
}

// ── 6. Tunggu Actions selesai + download APK ────────────
async function waitAndDownload() {
  log("Tunggu Actions jalan... (cek tiap 15 detik)");
  await sleep(10000);

  let runId = null;
  for (let i = 0; i < 40; i++) {
    const { data } = await octokit.actions.listWorkflowRunsForRepo({
      owner, repo, per_page: 1,
    });
    const run = data.workflow_runs[0];
    if (!run) { await sleep(15000); continue; }

    runId = run.id;
    log(`Run #${runId} — status: ${run.status}, conclusion: ${run.conclusion || "running"}`);

    if (run.status === "completed") {
      if (run.conclusion === "success") break;
      else {
        log("Build GAGAL. Cek Actions di GitHub.");
        process.exit(1);
      }
    }
    await sleep(15000);
  }

  if (!runId) { log("Timeout nunggu Actions."); process.exit(1); }

  // Download artifact
  log("Download APK artifact...");
  const { data: arts } = await octokit.actions.listWorkflowRunArtifacts({
    owner, repo, run_id: runId,
  });

  const art = arts.artifacts.find(a => a.name === "remote-controller");
  if (!art) { log("Artifact tidak ditemukan."); process.exit(1); }

  const dl = await octokit.actions.downloadArtifact({
    owner, repo,
    artifact_id: art.id,
    archive_format: "zip",
  });

  const outPath = path.join(__dirname, "remote_controller.zip");
  fs.writeFileSync(outPath, Buffer.from(dl.data));
  log(`APK tersimpan di: ${outPath}`);
  log("Extract zip untuk dapat .apk-nya.");
}

// ── Main ─────────────────────────────────────────────────
(async () => {
  try {
    await ensureRepo();
    await pushAndroidProject();
    await pushWorkflow();
    await waitAndDownload();
  } catch (e) {
    console.error("ERROR:", e.message || e);
    process.exit(1);
  }
})();
