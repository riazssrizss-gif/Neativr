# Remote Controller — Auto Build

## Setup

1. **Buat GitHub Personal Access Token**
   - GitHub → Settings → Developer settings → Personal access tokens → Fine-grained tokens
   - Atau classic token dengan scope: `repo` + `workflow`
   - Copy token-nya

2. **Isi config.js**
   - Buka `config.js`
   - Isi `token`, `owner` (username GitHub lo), `repo` (nama repo baru/existing)

3. **Install dependencies**
   ```
   npm install
   ```

4. **Jalankan build**
   ```
   node build.js
   ```

## Yang terjadi otomatis
- Repo dibuat di GitHub (kalau belum ada)
- Semua source code di-push
- GitHub Actions jalan build APK native
- APK di-download ke folder ini sebagai `remote_controller.zip`

## Hasil
Extract `remote_controller.zip` → ada file `.apk` di dalamnya → install langsung.

## Signing
- Default: debug signing (pasti valid, langsung install)
- Mau custom keystore: set `keystore.use: true` di config.js
